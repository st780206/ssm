tinymce.addI18n('ug',# Generated pot
# Translators:
# uyson <uyson@qq.com>, 2013
# ياسىن ئېلى <yasinjaneli@gmail.com>, 2016
msgid ""
msgstr ""
"Project-Id-Version: TinyMCE\n"
"Report-Msgid-Bugs-To: http://moxiecode.com\n"
"POT-Creation-Date: 2013-03-21 16:18:52+00:00\n"
"PO-Revision-Date: 2016-08-24 10:49+0000\n"
"Last-Translator: Joakim Lindkvist <info@moxiecode.com>\n"
"Language-Team: Uighur (http://www.transifex.com/moxiecode/tinymce/language/ug/)\n"
"MIME-Version: 1.0\n"
"Content-Type: text/plain; charset=UTF-8\n"
"Content-Transfer-Encoding: 8bit\n"
"\"#: i18n:\n"
"Language: ug\n"
"Plural-Forms: nplurals=1; plural=0;\n"

msgid "File"
msgstr "ھۆججەت"

msgid "Edit"
msgstr "تەھرىرلەش"

msgid "Insert"
msgstr "قىستۇرۇش"

msgid "View"
msgstr "كۆرۈش"

msgid "Format"
msgstr "فورمات"

msgid "Table"
msgstr "جەدۋەل"

msgid "Tools"
msgstr "قۇرال"

msgid ""
"Rich Text Area. Press ALT-F9 for menu. Press ALT-F10 for toolbar. Press "
"ALT-0 for help"
msgstr "مول مەزمۇنلۇق تېكېسىت رامكىسى رايونىدا تىزىملىك ئۈچۈن ALT-F9 نى، قورال بالدىقى ئۈچۈن ALT-F10 نى، ياردەم ئۈچۈن ALT-0 نى بېسىڭ"
);