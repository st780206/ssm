tinymce.addI18n('vi_VN',# Generated pot
# Translators:
# Ly Qui Chung <wolftg@gmail.com>, 2013
msgid ""
msgstr ""
"Project-Id-Version: TinyMCE\n"
"Report-Msgid-Bugs-To: http://moxiecode.com\n"
"POT-Creation-Date: 2013-03-21 16:18:52+00:00\n"
"PO-Revision-Date: 2016-08-24 10:47+0000\n"
"Last-Translator: Joakim Lindkvist <info@moxiecode.com>\n"
"Language-Team: Vietnamese (Viet Nam) (http://www.transifex.com/moxiecode/tinymce/language/vi_VN/)\n"
"MIME-Version: 1.0\n"
"Content-Type: text/plain; charset=UTF-8\n"
"Content-Transfer-Encoding: 8bit\n"
"\"#: i18n:\n"
"Language: vi_VN\n"
"Plural-Forms: nplurals=1; plural=0;\n"

msgid "File"
msgstr "Tập tin"

msgid "Edit"
msgstr "Sửa"

msgid "Insert"
msgstr "Thêm"

msgid "View"
msgstr "Xem"

msgid "Format"
msgstr "Định dạng"

msgid "Table"
msgstr "Bảng"

msgid "Tools"
msgstr "Công cụ"

msgid ""
"Rich Text Area. Press ALT-F9 for menu. Press ALT-F10 for toolbar. Press "
"ALT-0 for help"
msgstr "Khu vực soạn thảo. Nhấn ALT-F9 để hiện menu, ALT-F10 để hiện thanh công cụ. Cần trợ giúp nhấn ALT-0"
);